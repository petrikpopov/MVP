﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MPV_END
{
    public partial class Form1 : Form, IView
    {
<<<<<<< HEAD
       
=======
        
>>>>>>> Поиск не очень получилось сделать
        public Form1()
        {
            InitializeComponent();
        }
        public ListBox SearchResultsListBox { get { return SearchResultsListBox; } }
        public string Name_P
        {
            set { textBox1.Text = value; }
            get { return textBox1.Text; }
        }
        public string Age_P
        {
            set { textBox2.Text = value; }
            get { return textBox2.Text; }
        }

        public event EventHandler<EventArgs> buut;
        public event EventHandler<EventArgs> print;
        public event EventHandler<EventArgs> find;
        public void AddItemToListBox(string item)
        {
            listBox1.Items.Add(item);
            
        }
        public void ShowInfoPersone(string name, string age)
        {
            this.Name_P = name;
            this.Age_P = age;
            listBox1.Text = $"Name:{name}\tAge:{age}";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            buut?.Invoke(this, EventArgs.Empty);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            print?.Invoke(this,EventArgs.Empty);
        }

       
    }
}
