﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MPV_END
{
    public class Presenter
    {
        public readonly IModel model;
        public readonly IView view;
        public Presenter() { }
        public Presenter(IModel _model, IView _view)
        {
            model = _model;
            view = _view;

            view.buut += View_buut;
            view.print += View_buut_print;


        }

        private void View_buut_print(object sender, EventArgs e)
        {
            model.Name_P = view.Name_P;
            model.Age_P = view.Age_P;
           
            string item = $"Name={model.Name_P},Age={model.Age_P}";

            view.AddItemToListBox(item); 
            
        }
        
    

        private void View_buut(object sender, EventArgs e)
        {

            model.Name_P = view.Name_P;
            model.Age_P = view.Age_P;

            model.AddInfoFile_P();

        }
    }
}
