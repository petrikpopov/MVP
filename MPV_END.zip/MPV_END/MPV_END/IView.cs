﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MPV_END
{
    public interface IView
    {
        string Name_P { set; get; }
        string Age_P { set; get; }
        
        event EventHandler<EventArgs> buut;
        event EventHandler<EventArgs> print;
        
        void AddItemToListBox(string item);
        void ShowInfoPersone(string name, string age);
    }
}
